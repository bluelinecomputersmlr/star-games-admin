<!DOCTYPE html>

<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Chart</title>
</head>
<body>


 <style>html{overflow-x:hidden;scroll-behavior:smooth}body{background-color:black;text-align:center;padding:3px 10px;margin:0;scroll-behavior:smooth;font-style:italic;font-family:Helvetica,sans-serif;font-weight:700}*{margin:0;padding:0;box-sizing:border-box}a:hover,a{text-decoration:none}.faq h4,.faq p,.faq a,.disclamer h2,.disclamer p,.about-us p,.about-us b,.about-us a,.ftr-sm h2,.ftr-sm p,.pby-us{font-style:normal}.paid-gm p,.matka-card>div,.satta-result div{border-bottom:1px solid #4b3730}.logo,.mrque-div,.satta-text,.cm-patti,.matka-result,.conta,.slash-text,.satta-result,.paid-gm,.blue-div,.red-list>div,.purpel-header,.faq,.disclamer,.about-us,.ftr-sm,.pby-us{border:2px solid #eb008b;border-radius:10px 0 10px 10px;margin-bottom:2px;overflow:hidden}.paid-gm p,.matka-card>div,.satta-result div{border-bottom:1px solid #0d6059}.logo img{width:220px;height:auto;padding:6px 0 0}.mrque-div{display:flex;padding:5px;align-items:center}.mrque-div img{width:90px;height:auto;border-radius:5px}.mrque-div marquee{color:red;font-size:15px}.satta-text{padding:5px}.satta-text h1{font-size:16px;color:#1a237e;padding-bottom:3px}.satta-text p{color:#444;font-size:14px}.cm-patti{border-color:#1a237e}.cm-patti .row{display:-webkit-flex;display:-moz-flex;display:-ms-flex;display:-o-flex;display:flex}.cm-patti .row>div{width:50%}.cm-patti h4{font-size:24px;color:#ff0;text-shadow:1px 1px 3px #000000}.cm-patti p{font-size:22px;color:#cc217f;text-shadow:1px 1px 2px #ffe0c0}.cm-patti .aa55{border-right:1px solid #e91e63}.cm-patti .bb55{border-left:1px solid #e91e63}.cm-patti h3{margin:0;background-image:linear-gradient(45deg,#9c27b0,#e91e63,#9c27b0);color:#fff;padding-top:2px;border-bottom:1px solid #ffffff61;font-size:22px}.matka-result{}.matka-result h4{background-color:#1a237e!important;color:#fff;padding-top:2px;padding-bottom:4px;font-size:30px}.matka-card>div{padding-bottom:4px;padding-bottom:4px}.matka-card>div:last-child{border-width:0px}.matka-card h6{font-size:22px!important;color:#880e4f;text-shadow:1px 1px 2px #ffe2c6}.matka-card h5{font-size:21px!important;color:#4a148c;text-shadow:1px 1px 2px #fdf3ff;line-height:1}.refresh-btn,.matka-card a{border:2px solid #ff006c;background-color:#ff006c;color:#fff;padding:3px 7px;border-radius:8px 0;box-shadow:0px 0px 1px #000000d6;font-size:12px;margin:2px 0 -1px;display:inline-block;transition:all .3s}.refresh-btn:hover,.matka-card a:hover{border:2px solid #ba004f;background-color:#ba004f;box-shadow:0px 0px 13px 3px #00000033;cursor:pointer}.conta{padding-top:4px;padding-bottom:7px;background-color:#fbe7ff;display:-webkit-flex;display:-moz-flex;display:-ms-flex;display:-o-flex;display:flex;-ms-align-items:center;align-items:center;justify-content:center}.conta p{font-size:22px;color:#ed143d;display:flex;flex-direction:column;justify-content:center;margin-right:12px}.conta a{background-color:#ffc107;color:#000;padding:5px 8px 2px;border-radius:80px;display:inline-block;box-shadow:0 0 10px -3px #000;border:1px solid #ee008d;font-size:18px}.conta a:hover{box-shadow:0 0 10px 0px #000}.slash-text{color:#000;line-height:1.4;font-size:14px;padding:4px 10px;text-shadow:1px 1px #f4e1e1}.banner{border-radius:4px;background:#aa00c0;color:#fff;text-shadow:1px 1px 0 #444;letter-spacing:1px;font-size:24px;padding:4px 4px 4px;margin-bottom:2px}.satta-result{}.satta-result h4{font-size:22px;background-color:transparent;color:#1a237e;text-shadow:1px 1px #d9d9d9}.satta-result h5{margin:0;font-size:22px;background-color:transparent;color:#880e4f;text-shadow:1px 1px #0000001f;line-height:1}.satta-result h6{color:#7a028d;font-size:15px;padding:2px 0;text-shadow:1px 1px 2px #c4c4c4;margin-bottom:0}.satta-result div{padding:3px}.satta-result div:last-child{border-bottom-width:0}.yellowbg{background-color:#ff0;border-bottom:1px solid #FF9800!important}.paid-gm{border-color:#085e58}.paid-gm h4{background-color:#085e58;color:#fff;font-size:28px;padding:3px 0 4px}.paid-gm img{border:2px solid #085e58;border-radius:10px 0 10px 10px;width:250px;height:auto;margin-top:4px}.paid-gm p{padding:6px 20px;text-shadow:1px 1px 2px #eee}.paid-gm .aa,.paid-gm .bb{color:#000;font-size:18px}.paid-gm .bb,.paid-gm .cc,.paid-gm .dd{color:#085e58}.paid-gm .cc{font-size:19px}.paid-gm .dd{font-size:20px}.paid-gm .ee{color:#e91e63;padding-bottom:3px;font-size:21px}.paid-gm .ff{color:#e91e63;font-size:15px}.paid-gm .gg{color:#000;font-size:32px}.paid-gm span{display:block}.my-table{margin-bottom:2px}.my-table h4{border:solid 2px #e91e63;border-bottom-width:0;padding:3px 5px 2px;font-size:24px}.my-table table{border-collapse:collapse;width:100%}.my-table thead{background-color:#efefef;font-size:16px}.my-table tbody{font-size:16px}.my-table th,.my-table td{border:2px solid #e91e63}.my-table th,.my-table td{padding:2px 0;font-size:15px}.my-table th{color:#e91e63}.my-table td{}.my-table tr td:nth-child(2),.my-table tr td:nth-child(4){color:#00f}.my-table.cm-sl h2,.my-table.mr-sl h2{background-color:yellow;color:blue}.my-table.mumraj-sl h4{background-color:#800080;color:#fff}.blue-div{border:2px solid #1f3092}.blue-div h4{background-color:#1f3092;color:#fff;font-size:30px;padding:3px 5px}.blue-div a{color:#000;font-size:22px;display:block;border-bottom:2px solid #1f3092;padding:5px}.blue-div a:last-child{border-bottom-width:0px}.red-list{}.red-list>div{}.red-list h4{background-color:#e71d36;color:#fff;line-height:1.1;padding:4px 10px 3px;text-shadow:1px 1px 2px #000;font-size:24px}.red-list p{font-size:18px;text-align:center;line-height:1.3}.purpel-header{}.purpel-header h4{color:#fff;padding:5px 10px 3px;font-size:24px}.purpel-header a{display:block;font-size:22px;padding:5px 7px 4px}.ab1 a{border-bottom:2px solid #024c88;color:#003c6c}.purpel-header a:last-child{border-bottom-width:0}.ab1{border-color:#024c88}.ab1 h4{background-color:#024c88}.ab2 a{border-bottom:2px solid #460000;color:#460000}.ab2{border-color:#460000}.ab2 h4{background-color:#460000}.faq{}.faq h4{color:#d70544;font-size:22px;padding:5px 5px 6px;border-top:1.5px solid #e0557f;margin-top:5px}.faq h4:first-child{border-top-width:0;margin-top:0}.faq p{font-size:12px;padding:0 5px 15px;line-height:1.4;color:#1a1a1a}.faq a{color:#d70544;text-decoration:underline}@media only screen and (max-width:768px){.faq h4{font-size:15px}}.disclamer{}.disclamer h4{color:#fff;font-size:18px;margin-bottom:5px;background-color:#eb3269;padding-top:4px;text-shadow:1px 1px 3px #000}.disclamer p{font-size:13px;color:#340d7a;padding:2px 5px 5px;line-height:1.2}.about-us{padding:5px}.about-us p{font-size:13px;margin-bottom:0;color:#000;padding-bottom:15px;text-shadow:1px 1px #f4e1e1}.about-us b{color:#d70544;text-transform:uppercase}.about-us a{background-color:#e91e63;color:#fff;padding:4px 6px;display:inline-block;text-shadow:1px 1px 2px #2f2f2f;border-radius:4px}.ftr-sm{padding:5px}.ftr-sm h4{font-size:18px;margin-bottom:4px;color:#d3003f}.ftr-sm p{color:#a50031;font-size:10px;line-height:1.4;text-shadow:1px 1px #f4e1e1}.pby-us{text-shadow:1px 1px #f4e1e1;color:#000;padding-top:2px;padding-bottom:1px}.refresh-btn{position:fixed;bottom:10px;right:10px}.bdr-b-0{border-width:0!important}.p-0{padding:0!important}@media only screen and (max-width:768px){}@media only screen and (max-width:500px){body{padding:2px 5px}.logo img{width:200px}.faq h4{font-size:15px}}@media only screen and (max-width:375px){}@media only screen and (max-width:320px){}/* end media 

</style>


<div style="color: rgb(0, 0, 0); overflow: auto; --darkreader-inline-color:#e8e6e3;" align="center" id="content" data-darkreader-inline-color="">
<div><table id="example" border="1" bgcolor="white" style="text-align: center; width: 100%; --darkreader-inline-bgcolor:#181a1b;" data-darkreader-inline-bgcolor="">
<tbody> <tr style="padding: 0">
<td colspan="13" style="padding:0">
<div style="background-color: rgb(242, 247, 37); text-transform: uppercase; --darkreader-inline-bgcolor:#b1b407;" data-darkreader-inline-bgcolor="">
<font size="5" color="#181ff2" data-darkreader-inline-color="">CMM Kolkata Chart</font>
</div> </td></tr>
<tr style="background-color: rgba(242, 247, 37, 0.4); --darkreader-inline-bgcolor:rgba(177, 180, 7, 0.4);">
<td> <p align="center" class="Rhead"> DATE</p></td>
<td valign="middle" align="center" class="Rhead">09:30AM </td>
<td valign="middle" align="center" class="Rhead">10:30AM </td>
<td valign="middle" align="center" class="Rhead">11:30AM </td>
<td valign="middle" align="center" class="Rhead">12:30PM </td>
<td valign="middle" align="center" class="Rhead">01:30PM </td>
<td valign="middle" align="center" class="Rhead">02:3OPM </td>
<td valign="middle" align="center" class="Rhead">03:30PM </td>
<td valign="middle" align="center" class="Rhead">04:30PM </td>
<td valign="middle" align="center" class="Rhead">05:30PM </td>
<td valign="middle" align="center" class="Rhead">06:30PM </td>
<td valign="middle" align="center" class="Rhead">07:30PM </td>
<td valign="middle" align="center" class="Rhead">08:30PM </td>
</tr><tr><td><span>
24-05-2021
<br>Monday
<br> 
</span></td>
<td> <span>889</span> <br> <span>5</span></td>
<td> <span>269</span> <br> <span>7</span></td>
<td> <span>347</span> <br> <span>4</span></td>
<td> <span>168</span> <br> <span>5</span></td>
<td> <span>489</span> <br> <span>1</span></td>
<td> <span>140</span> <br> <span>5</span></td>
<td> <span>660</span> <br> <span>2</span></td>
<td> <span>346</span> <br> <span>3</span></td>
<td> <span>289</span> <br> <span>9</span></td>
<td> <span>348</span> <br> <span>5</span></td>
<td> <span>568</span> <br> <span>9</span></td>
<td> <span>378</span> <br> <span>8</span></td>

</tr>
<tr><td><span>
25-05-2021
<br>Tuesday
<br> 
</span></td>
<td> <span>280</span> <br> <span>0</span></td>
<td> <span>479</span> <br> <span>0</span></td>
<td> <span>330</span> <br> <span>6</span></td>
<td> <span>290</span> <br> <span>1</span></td>
<td> <span>458</span> <br> <span>7</span></td>
<td> <span>579</span> <br> <span>1</span></td>
<td> <span>169</span> <br> <span>6</span></td>
<td> <span>138</span> <br> <span>2</span></td>
<td> <span>457</span> <br> <span>6</span></td>
<td> <span>446</span> <br> <span>4</span></td>
<td> <span>780</span> <br> <span>5</span></td>
<td> <span>***</span> <br> <span>*</span></td>

</tr>
<tr><td><span>
26-05-2021
<br>Wednesday
<br> 
</span></td>
<td> <span>890</span> <br> <span>7</span></td>
<td> <span>129</span> <br> <span>2</span></td>
<td> <span>236</span> <br> <span>1</span></td>
<td> <span>599</span> <br> <span>3</span></td>
<td> <span>280</span> <br> <span>0</span></td>
<td> <span>370</span> <br> <span>0</span></td>
<td> <span>338</span> <br> <span>4</span></td>
<td> <span>256</span> <br> <span>3</span></td>
<td> <span>136</span> <br> <span>0</span></td>
<td> <span>246</span> <br> <span>2</span></td>
<td> <span>116</span> <br> <span>8</span></td>
<td> <span>590</span> <br> <span>4</span></td>

</tr>
<tr><td><span>
27-05-2021
<br>Thursday
<br> 
</span></td>
<td> <span>579</span> <br> <span>1</span></td>
<td> <span>357</span> <br> <span>5</span></td>
<td> <span>239</span> <br> <span>4</span></td>
<td> <span>336</span> <br> <span>2</span></td>
<td> <span>290</span> <br> <span>1</span></td>
<td> <span>589</span> <br> <span>2</span></td>
<td> <span>779</span> <br> <span>3</span></td>
<td> <span>168</span> <br> <span>5</span></td>
<td> <span>570</span> <br> <span>2</span></td>
<td> <span>456</span> <br> <span>5</span></td>
<td> <span>149</span> <br> <span>4</span></td>
<td> <span>700</span> <br> <span>7</span></td>

</tr>
<tr><td><span>
28-05-2021
<br>Friday
<br> 
</span></td>
<td> <span>140</span> <br> <span>5</span></td>
<td> <span>478</span> <br> <span>9</span></td>
<td> <span>289</span> <br> <span>9</span></td>
<td> <span>477</span> <br> <span>8</span></td>
<td> <span>146</span> <br> <span>1</span></td>
<td> <span>490</span> <br> <span>3</span></td>
<td> <span>237</span> <br> <span>2</span></td>
<td> <span>360</span> <br> <span>9</span></td>
<td> <span>556</span> <br> <span>6</span></td>
<td> <span>138</span> <br> <span>2</span></td>
<td> <span>267</span> <br> <span>5</span></td>
<td> <span>560</span> <br> <span>1</span></td>

</tr>
<tr><td><span>
29-05-2021
<br>Saturday
<br> 
</span></td>
<td> <span>125</span> <br> <span>8</span></td>
<td> <span>378</span> <br> <span>8</span></td>
<td> <span>129</span> <br> <span>2</span></td>
<td> <span>244</span> <br> <span>0</span></td>
<td> <span>345</span> <br> <span>2</span></td>
<td> <span>148</span> <br> <span>3</span></td>
<td> <span>458</span> <br> <span>7</span></td>
<td> <span>679</span> <br> <span>2</span></td>
<td> <span>340</span> <br> <span>7</span></td>
<td> <span>177</span> <br> <span>5</span></td>
<td> <span>258</span> <br> <span>5</span></td>
<td> <span>237</span> <br> <span>2</span></td>

</tr>
<tr><td><span>
30-05-2021
<br>Sunday
<br> 
</span></td>
<td> <span>137</span> <br> <span>1</span></td>
<td> <span>249</span> <br> <span>5</span></td>
<td> <span>370</span> <br> <span>0</span></td>
<td> <span>445</span> <br> <span>3</span></td>
<td> <span>237</span> <br> <span>2</span></td>
<td> <span>225</span> <br> <span>9</span></td>

</tr>

</tbody></table>


</div></div>

</body></html>